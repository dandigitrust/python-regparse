==========
PluginInfo
==========

.. automodule:: yapsy.PluginInfo
   :members:
   :undoc-members:   

