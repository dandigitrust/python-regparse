AutoInstallPluginManager
========================

.. automodule:: yapsy.AutoInstallPluginManager
   :members:
   :undoc-members:   

